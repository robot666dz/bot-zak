import json
import random
import logging
import os
import threading
from flask import Flask
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

# --- Flask Server for Keep-Alive ---
app = Flask(__name__)

@app.route('/')
def health_check():
    return "Bot is running!", 200

def run_flask():
    # Render provides a PORT environment variable
    port = int(os.environ.get("PORT", 8080))
    app.run(host='0.0.0.0', port=port)

# --- Bot Logic ---
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

TOKEN = "8653067393:AAGtL1V2-M36zmfQmgH73NDmlPxQ2vzRpjg"

# Load data
def load_participants():
    try:
        with open('participants.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return []

PARTICIPANTS = load_participants()

ADVISER_GROUPS = {
    "toroshchinaaa": "Team_Toroshchina",
    "khanfer_abed": "Team_Khanfer",
    "Husseinshamil": "Team_Hussein",
    "Angealia": "Team_Angealia",
    "Angeleena04": "Team_Angeleena",
    "KiddPunkRiot": "Team_KiddPunkRiot",
    "shri9360": "Team_Shri",
    "globglobgabgalab08": "Team_GlobGlob",
    "S_01111010_01100001_01101011": "Team_Shah_Zak",
    "Its_shah_250603": "Team_Shah_Zak",
    "xeshi_x": "Team_Xeshi_Hiba",
    "hibbachii": "Team_Xeshi_Hiba",
    "hibasinath": "Team_Xeshi_Hiba"
}

assignments = {}

def perform_assignment():
    global assignments
    assigned_names = set()
    green_students = [p for p in PARTICIPANTS if p['is_green']]
    normal_students = [p for p in PARTICIPANTS if not p['is_green']]
    
    random.shuffle(green_students)
    random.shuffle(normal_students)
    
    new_assignments = {}
    unique_groups = list(set(ADVISER_GROUPS.values()))
    
    # 1. Special case for @toroshchinaaa
    torosh_list = []
    fatola = next((p for p in green_students if p['name'] == "Fatola Oluwatosin David"), None)
    if fatola:
        torosh_list.append(fatola)
        green_students.remove(fatola)
        assigned_names.add(fatola['name'])
    udechi = next((p for p in normal_students if p['name'] == "Udechi Amarachi Benedicta"), None)
    if udechi:
        torosh_list.append(udechi)
        normal_students.remove(udechi)
        assigned_names.add(udechi['name'])
    while len(torosh_list) < 4 and normal_students:
        p = normal_students.pop()
        torosh_list.append(p)
        assigned_names.add(p['name'])
    new_assignments["Team_Toroshchina"] = torosh_list

    # 2. Assign for other unique groups
    other_groups = [g for g in unique_groups if g != "Team_Toroshchina"]
    random.shuffle(other_groups)
    for group in other_groups:
        group_list = []
        if green_students:
            green = green_students.pop()
            group_list.append(green)
            assigned_names.add(green['name'])
        while len(group_list) < 4 and normal_students:
            p = normal_students.pop()
            group_list.append(p)
            assigned_names.add(p['name'])
        new_assignments[group] = group_list
    assignments = new_assignments

perform_assignment()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    username = user.username
    group_id = ADVISER_GROUPS.get(username)
    if not group_id:
        group_id = "Team_Xeshi_Hiba"
    my_participants = assignments.get(group_id, [])
    if not my_participants:
        await update.message.reply_text("⚠️ Sorry, I couldn't find your team assignment.")
        return
    response = f"Hello @{username}!\n\nHere is your team (4 participants):\n"
    response += "----------------------------------\n"
    for i, p in enumerate(my_participants, 1):
        status = "🟢" if p['is_green'] else "⚪"
        response += f"{i}. {p['name']} {status}\n"
    response += "----------------------------------\n"
    response += "\n✅ Rules applied:\n- 1 Green student per team\n- 4 Total participants per team\n- No duplicates across teams"
    await update.message.reply_text(response)

async def list_all(update: Update, context: ContextTypes.DEFAULT_TYPE):
    response = "📋 **FULL ASSIGNMENT LIST**\n\n"
    for group, members in assignments.items():
        response += f"🔹 {group}:\n"
        for m in members:
            status = "🟢" if m['is_green'] else "⚪"
            response += f"  - {m['name']} {status}\n"
        response += "\n"
    if len(response) > 4000:
        for x in range(0, len(response), 4000):
            await update.message.reply_text(response[x:x+4000])
    else:
        await update.message.reply_text(response)

if __name__ == '__main__':
    # Start Flask in a separate thread
    threading.Thread(target=run_flask, daemon=True).start()
    
    # Start Telegram Bot
    application = ApplicationBuilder().token(TOKEN).build()
    application.add_handler(CommandHandler('start', start))
    application.add_handler(CommandHandler('list', list_all))
    print("Bot is starting...")
    application.run_polling(drop_pending_updates=True)
